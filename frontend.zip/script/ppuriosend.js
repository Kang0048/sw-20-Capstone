import { requestSend } from './ppurio/ppurio.js';

document.addEventListener('DOMContentLoaded', () => {
    const ppurioData = {
        from: '',
        name: '',
        to: [],
        content: '',
        image: ''
    };

    // 발신번호와 이름 처리
    const phoneNumberInput = document.getElementById('phoneNumberInput');
    const ownerInput = document.getElementById('ownerInput');

    if (phoneNumberInput && ownerInput) {
        phoneNumberInput.addEventListener('input', () => {
            ppurioData.from = phoneNumberInput.value;
        });

        ownerInput.addEventListener('input', () => {
            ppurioData.name = ownerInput.value;
        });
    }

    // 수신번호 리스트 처리
    const recipientList = document.getElementById('recipientlist');
    if (recipientList) {
        const numbers = recipientList.textContent.split('\n');
        ppurioData.to = numbers.map(number => number.trim()).filter(number => number);
    }

    // 문자 내용 처리
    const messageContent = document.getElementById('messageContent');
    if (messageContent) {
        messageContent.addEventListener('input', () => {
            ppurioData.content = messageContent.value;
        });
    }

    // 이미지 경로 처리
    const imagePreview = document.getElementById('imagePreview');
    if (imagePreview) {
        const imgElement = imagePreview.querySelector('img');
        if (imgElement) {
            ppurioData.image = imgElement.src;
        }
    }

    // 전송 버튼 클릭 시 실행
    window.sendMessage = async () => {
        console.log('sendMessage 함수 호출됨');
        if (!ppurioData.from || !ppurioData.to.length || !ppurioData.content) {
            alert('발신번호, 수신번호, 또는 문자 내용을 입력하세요.');
            return;
        }

        try {
            const result = await requestSend(
                ppurioData.to,
                ppurioData.from,
                ppurioData.name,
                ppurioData.content,
                ppurioData.image
            );
            console.log('전송 성공:', result);
            alert('메시지가 성공적으로 전송되었습니다.');
        } catch (error) {
            console.error('전송 실패:', error);
            alert('메시지 전송에 실패했습니다.');
        }
    };
});
